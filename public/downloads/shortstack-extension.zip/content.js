/* ShortStack OS — Content Script */
(() => {
  /* On ShortStack pages, just set a marker so the OS knows the extension is installed */
  if ((location.hostname === "localhost" && location.port === "3000") || location.hostname.includes("shortstack.app")) {
    document.documentElement.setAttribute("data-shortstack-ext", "1");
    return;
  }

  /* ── Floating Action Button ── */
  const fab = document.createElement("button");
  fab.className = "shortstack-ext-fab";
  fab.innerHTML = "&#9889;";
  fab.title = "ShortStack OS";
  document.body.appendChild(fab);

  /* ── Sidebar ── */
  const sidebar = document.createElement("div");
  sidebar.className = "shortstack-ext-sidebar";
  sidebar.innerHTML = buildSidebar();
  document.body.appendChild(sidebar);

  fab.addEventListener("click", (e) => {
    e.stopPropagation();
    sidebar.classList.toggle("open");
    if (sidebar.classList.contains("open")) refreshSidebar();
  });

  /* Close sidebar */
  sidebar.querySelector(".shortstack-ext-close").addEventListener("click", () => sidebar.classList.remove("open"));
  document.addEventListener("click", (e) => {
    if (!sidebar.contains(e.target) && e.target !== fab) sidebar.classList.remove("open");
  });

  /* Add-lead button inside sidebar */
  sidebar.querySelector("#ssExtAddLead").addEventListener("click", () => {
    const info = detectPageInfo();
    chrome.runtime.sendMessage({
      action: "addLead",
      data: { name: info.title, email: info.emails[0] || "", phone: info.phones[0] || "", source: location.href },
      label: info.title,
    });
    const btn = sidebar.querySelector("#ssExtAddLead");
    btn.textContent = "Saved!";
    setTimeout(() => (btn.textContent = "Add as Lead"), 1500);
  });

  /* ── Selection Toolbar ── */
  let toolbar = null;
  document.addEventListener("mouseup", (e) => {
    removeToolbar();
    const sel = window.getSelection().toString().trim();
    if (!sel || sel.length < 3) return;
    toolbar = document.createElement("div");
    toolbar.className = "shortstack-ext-toolbar";
    toolbar.innerHTML = `<button data-act="createPost">Post</button><button data-act="saveNote">Note</button><button data-act="summarize">Summarize</button>`;
    toolbar.style.left = `${Math.min(e.pageX, window.innerWidth - 200)}px`;
    toolbar.style.top = `${e.pageY + 10}px`;
    document.body.appendChild(toolbar);

    toolbar.querySelectorAll("button").forEach((btn) => {
      btn.addEventListener("click", () => {
        chrome.runtime.sendMessage({
          action: btn.dataset.act,
          data: { content: sel, url: location.href },
          label: sel.slice(0, 40),
        });
        removeToolbar();
      });
    });
  });

  document.addEventListener("mousedown", () => removeToolbar());

  function removeToolbar() {
    if (toolbar) { toolbar.remove(); toolbar = null; }
  }

  /* ── Helpers ── */
  function detectPageInfo() {
    const title = document.title || "";
    const desc = document.querySelector('meta[name="description"]')?.content || "";
    const bodyText = document.body.innerText || "";
    const emails = [...new Set((bodyText.match(/[\w.+-]+@[\w-]+\.[\w.]+/g) || []).slice(0, 5))];
    const phones = [...new Set((bodyText.match(/(\+?1?\s?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4})/g) || []).slice(0, 5))];
    /* Business detection: Google Maps / schema.org */
    let biz = {};
    const ld = document.querySelector('script[type="application/ld+json"]');
    if (ld) {
      try {
        const j = JSON.parse(ld.textContent);
        if (j["@type"] === "LocalBusiness" || j["@type"] === "Organization") {
          biz = { name: j.name, phone: j.telephone, address: j.address?.streetAddress, rating: j.aggregateRating?.ratingValue };
        }
      } catch (_) {}
    }
    return { title, desc, emails, phones, biz };
  }

  function refreshSidebar() {
    const info = detectPageInfo();
    const set = (id, val) => { const el = sidebar.querySelector(`#${id}`); if (el) el.textContent = val || "—"; };
    set("ssTitle", info.title);
    set("ssDesc", info.desc || "None detected");
    set("ssEmails", info.emails.join(", ") || "None");
    set("ssPhones", info.phones.join(", ") || "None");
    if (info.biz.name) {
      set("ssBizName", info.biz.name);
      sidebar.querySelector("#ssBizSection").style.display = "block";
    }
  }

  function buildSidebar() {
    return `
      <div class="shortstack-ext-sidebar-header">
        <h2>ShortStack OS</h2>
        <button class="shortstack-ext-close">&times;</button>
      </div>
      <div class="shortstack-ext-section">
        <h3>Page Info</h3>
        <div class="shortstack-ext-row"><span class="label">Title</span><span class="value" id="ssTitle">—</span></div>
        <div class="shortstack-ext-row"><span class="label">Description</span><span class="value" id="ssDesc">—</span></div>
        <div class="shortstack-ext-row"><span class="label">Emails</span><span class="value" id="ssEmails">—</span></div>
        <div class="shortstack-ext-row"><span class="label">Phones</span><span class="value" id="ssPhones">—</span></div>
      </div>
      <div class="shortstack-ext-section" id="ssBizSection" style="display:none">
        <h3>Business Detected</h3>
        <div class="shortstack-ext-row"><span class="label">Name</span><span class="value" id="ssBizName">—</span></div>
      </div>
      <div class="shortstack-ext-section">
        <button class="shortstack-ext-btn" id="ssExtAddLead">Add as Lead</button>
      </div>`;
  }
})();
